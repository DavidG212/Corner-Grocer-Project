#David Garcia
#CS 210 Project 3 Corner Grocer

import re
import string
import os.path
from os import path


def numOfItems():  #declare numOfItems function to count number of times an item appears 
    file = open("U:\CornerGrocer\Release\CS210_Project_Three_Input_File.txt", "r")  #open txt file
    dictionary = dict()
    
    for line in file:
        line = line.strip()
        word = line.lower()

        if word in dictionary:
           dictionary[word] = dictionary[word] + 1
        else:
           dictionary[word] = 1

    for key in list (dictionary.keys()):
        print(key.capitalize(), ":", dictionary[key])

    file.close()  #close txt file 

def itemPurchased(searchItem):   #declare itemPurchased function to count amount of times searched items were purchased
    searchItem = searchItem.lower()

    file = open("U:\CornerGrocer\Release\CS210_Project_Three_Input_File.txt", "r")  #open txt file
    wordCount = 0

    for line in file:
        line = line.strip()
        word = line.lower()

        if word == searchItem:
           wordCount += 1

    return wordCount

    file.close()  #close txt file 

def dataHistogram():    #declare histogram function to print astericks for amount of times item was purchased 
    file = open("U:\CornerGrocer\Release\CS210_Project_Three_Input_File.txt", "r")  #open txt file 
    frequency = open("frequency.dat", "w")  #open frequency.dat
    dictionary = dict()
    
    for line in file:
        line = line.strip()
        word = line.lower()

        if word in dictionary:
            dictionary[word] = dictionary[word] + 1
        else:
            dictionary[word] = 1

    for key in list (dictionary.keys()):
        frequency.write(str(key.capitalize()) + " " + str(dictionary[key]) + "\n")

    file.close()  #close txt file 
    frequency.close()  #close frequency.dat


    
