//David Garcia
//CS 210 Project 3 Corner Grocer

#include <Python.h>
#include <iostream>
#include <Windows.h>
#include <cmath>
#include <string>
#include <fstream>  //fstream to allow to read files

using namespace std;

/*
Description:
	To call this function, simply pass the function name in Python that you wish to call.
Example:
	callProcedure("printsomething");
Output:
	Python will print on the screen: Hello from python!
Return:
	None
*/
void CallProcedure(string pName)
{
	char* procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("PrintMe","Test");
Output:
	Python will print on the screen:
		You sent me: Test
Return:
	100 is returned to the C++
*/
int callIntFunc(string proc, string param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char* paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

/*
Description:
	To call this function, pass the name of the Python functino you wish to call and the string parameter you want to send
Example:
	int x = callIntFunc("doublevalue",5);
Return:
	25 is returned to the C++
*/
int callIntFunc(string proc, int param)
{
	char* procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject* pName, * pModule, * pDict, * pFunc, * pValue = nullptr, * presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

void DisplayMenu() {    //declare DisplayMenu function
	int itemCount = 0;  //declare variables
	int wordCount = 0;
	int menuOption = 0;
	string itemName;
	string checkTerm;
	std::ifstream fileInput; //ifstream to allow to open and read txt file

	while (menuOption != 4) { //while loop to display menu while 4 is not pressed
		cout << "Enter a menu choice as 1, 2, 3, or 4." << endl;  //print menu options
		cout << "(1) Show a list of all items purchased in a day." << endl;
		cout << "(2) Show how many times a specific item was purchased in a day." << endl;
		cout << "(3) Show a histogram of all items purchased in a day." << endl;
		cout << "(4) Exit" << endl;
		cin >> menuOption;  //get user input
		
		switch (menuOption) {  //begin switch statement for user input
		case 1:
			CallProcedure("numOfItems");  //if one is pressed get numOfItems function from python code
			cout << endl;
			break;

		case 2:
			cout << "Enter the item you want to search." << endl;  //ask which item the user would like to search
			cin >> checkTerm;  //get input
			wordCount = callIntFunc("itemPurchased", checkTerm);  //assign wordCount to result of itemPurchased function from python code
			cout << endl << checkTerm << " : " << wordCount << endl << endl;  //print out results
			break;

		case 3:
			CallProcedure("dataHistogram");  //call on histogram function from python code
			fileInput.open("frequency.dat");
			fileInput >> itemName;
			fileInput >> itemCount;

			while (!fileInput.fail()) {      //while loop to iterate through items of file and print histogram astericks
				cout << itemName;

				for (int i = 0; i < itemCount; i++) {
					cout << std::right << "*";
				}
				cout << endl;
				fileInput >> itemName;
				fileInput >> itemCount;
			}
			fileInput.close();
			break;

		case 4:     //if 4 is pressed program is exited
			return;

		default:    //default case 
			cout << "Please enter valid input.";
			cout << endl;
			break;
		}
	}
}

void main()
{
	DisplayMenu();  //call DisplayMenu function
}